# FinSight — Bank Statement Analyzer

A full-stack web app to analyze bank statements with AI.  
**Stack:** HTML/CSS/JS (frontend) · Netlify Functions/Python (backend) · Groq AI (LLM)

---

## Deploy to Netlify

### One-click via Netlify UI (no CLI needed)

1. Push this repo to GitHub (or GitLab / Bitbucket).
2. Go to [app.netlify.com](https://app.netlify.com) → **Add new site → Import an existing project**.
3. Select your repo. Netlify auto-detects `netlify.toml` — no extra build settings needed.
4. Before deploying, add your environment variable:
   - **Site Settings → Environment Variables → Add variable**
   - Key: `GROQ_API_KEY`  Value: your Groq API key from [console.groq.com](https://console.groq.com)
5. Click **Deploy site**. Done.

### Local development with Netlify CLI

```bash
npm install -g netlify-cli
netlify login

# Copy and fill in env vars
cp .env.example .env

# Start local dev server (functions + static at http://localhost:8888)
netlify dev
```

---

## Project structure

```
.
├── index.html                      # Frontend (served as static file)
├── netlify.toml                    # Netlify build + redirect config
└── netlify/
    └── functions/
        ├── analyze.py              # POST /api/analyze  (PDF upload + AI)
        ├── health.py               # GET  /api/health
        └── requirements.txt        # Python deps for functions
```

---

## How it works

| Request | Handled by |
|---------|-----------|
| `GET /` | `index.html` (static) |
| `POST /api/analyze` | `netlify/functions/analyze.py` |
| `GET /api/health` | `netlify/functions/health.py` |

`netlify.toml` redirects `/api/*` to the corresponding `/.netlify/functions/*` path transparently, so the frontend doesn't need to know about Netlify's internal function URLs.

---

## Notes & limitations

- **Scanned PDFs won't work** — only text-based PDFs (standard bank exports).
- **Netlify free tier timeout is 10 seconds.** Large PDFs with slow AI responses may occasionally time out. Upgrade to Netlify Pro for a 26-second limit.
- Max file size: 20 MB (also subject to Netlify's 6 MB function request body limit on free tier — standard bank statements are well within this).
